										
										<!--begin::List Widget 2-->
										<div class="card card-xl-stretch mb-xl-8">
											<!--begin::Header-->
											<div class="card-header border-0">
												<h3 class="card-title fw-bolder text-dark">Authors</h3>
												<div class="card-toolbar">
													<!--begin::Menu-->
													<button type="button" class="btn btn-sm btn-icon btn-color-primary btn-active-light-primary" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
														<!--begin::Svg Icon | path: icons/duotune/general/gen024.svg-->
														<span class="svg-icon svg-icon-2">
															<svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24">
																<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																	<rect x="5" y="5" width="5" height="5" rx="1" fill="#000000" />
																	<rect x="14" y="5" width="5" height="5" rx="1" fill="#000000" opacity="0.3" />
																	<rect x="5" y="14" width="5" height="5" rx="1" fill="#000000" opacity="0.3" />
																	<rect x="14" y="14" width="5" height="5" rx="1" fill="#000000" opacity="0.3" />
																</g>
															</svg>
														</span>
														<!--end::Svg Icon-->
													</button>

<!--layout-partial:partials/menus/_menu-2.html-->

													<!--end::Menu-->
												</div>
											</div>
											<!--end::Header-->
											<!--begin::Body-->
											<div class="card-body pt-2">
												<!--begin::Item-->
												<div class="d-flex align-items-center mb-7">
													<!--begin::Avatar-->
													<div class="symbol symbol-50px me-5">
														<img src="assets/media/avatars/150-1.jpg" class="" alt="" />
													</div>
													<!--end::Avatar-->
													<!--begin::Text-->
													<div class="flex-grow-1">
														<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">Emma Smith</a>
														<span class="text-muted d-block fw-bold">Project Manager</span>
													</div>
													<!--end::Text-->
												</div>
												<!--end::Item-->
												<!--begin::Item-->
												<div class="d-flex align-items-center mb-7">
													<!--begin::Avatar-->
													<div class="symbol symbol-50px me-5">
														<img src="assets/media/avatars/150-4.jpg" class="" alt="" />
													</div>
													<!--end::Avatar-->
													<!--begin::Text-->
													<div class="flex-grow-1">
														<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">Sean Bean</a>
														<span class="text-muted d-block fw-bold">PHP, SQLite, Artisan CLI</span>
													</div>
													<!--end::Text-->
												</div>
												<!--end::Item-->
												<!--begin::Item-->
												<div class="d-flex align-items-center mb-7">
													<!--begin::Avatar-->
													<div class="symbol symbol-50px me-5">
														<img src="assets/media/avatars/150-12.jpg" class="" alt="" />
													</div>
													<!--end::Avatar-->
													<!--begin::Text-->
													<div class="flex-grow-1">
														<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">Brian Cox</a>
														<span class="text-muted d-block fw-bold">PHP, SQLite, Artisan CLI</span>
													</div>
													<!--end::Text-->
												</div>
												<!--end::Item-->
												<!--begin::Item-->
												<div class="d-flex align-items-center mb-7">
													<!--begin::Avatar-->
													<div class="symbol symbol-50px me-5">
														<img src="assets/media/avatars/150-8.jpg" class="" alt="" />
													</div>
													<!--end::Avatar-->
													<!--begin::Text-->
													<div class="flex-grow-1">
														<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">Francis Mitcham</a>
														<span class="text-muted d-block fw-bold">PHP, SQLite, Artisan CLI</span>
													</div>
													<!--end::Text-->
												</div>
												<!--end::Item-->
												<!--begin::Item-->
												<div class="d-flex align-items-center">
													<!--begin::Avatar-->
													<div class="symbol symbol-50px me-5">
														<img src="assets/media/avatars/150-6.jpg" class="" alt="" />
													</div>
													<!--end::Avatar-->
													<!--begin::Text-->
													<div class="flex-grow-1">
														<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">Dan Wilson</a>
														<span class="text-muted d-block fw-bold">PHP, SQLite, Artisan CLI</span>
													</div>
													<!--end::Text-->
												</div>
												<!--end::Item-->
											</div>
											<!--end::Body-->
										</div>
										<!--end::List Widget 2-->
										