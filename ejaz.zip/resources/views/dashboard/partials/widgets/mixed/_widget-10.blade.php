										
										<!--begin::Mixed Widget 10-->
										<div class="card card-xl-stretch-50 mb-5 mb-xl-8">
											<!--begin::Body-->
											<div class="card-body p-0 d-flex justify-content-between flex-column overflow-hidden">
												<!--begin::Hidden-->
												<div class="d-flex flex-stack flex-wrap flex-grow-1 px-9 pt-9 pb-3">
													<div class="me-2">
														<span class="fw-bolder text-gray-800 d-block fs-3">Sales</span>
														<span class="text-gray-400 fw-bold">Oct 8 - Oct 26 21</span>
													</div>
													<div class="fw-bolder fs-3 text-primary">$15,300</div>
												</div>
												<!--end::Hidden-->
												<!--begin::Chart-->
												<div class="mixed-widget-10-chart" data-kt-color="primary" style="height: 175px"></div>
												<!--end::Chart-->
											</div>
										</div>
										<!--end::Mixed Widget 10-->
										