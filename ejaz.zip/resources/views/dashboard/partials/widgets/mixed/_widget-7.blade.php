										
										<!--begin::Mixed Widget 7-->
										<div class="card card-xl-stretch-50 mb-5 mb-xl-8">
											<!--begin::Body-->
											<div class="card-body d-flex flex-column p-0">
												<!--begin::Stats-->
												<div class="flex-grow-1 card-p pb-0">
													<div class="d-flex flex-stack flex-wrap">
														<div class="me-2">
															<a href="#" class="text-dark text-hover-primary fw-bolder fs-3">Generate Reports</a>
															<div class="text-muted fs-7 fw-bold">Finance and accounting reports</div>
														</div>
														<div class="fw-bolder fs-3 text-primary">$24,500</div>
													</div>
												</div>
												<!--end::Stats-->
												<!--begin::Chart-->
												<div class="mixed-widget-7-chart card-rounded-bottom" data-kt-chart-color="primary" style="height: 150px"></div>
												<!--end::Chart-->
											</div>
											<!--end::Body-->
										</div>
										<!--end::Mixed Widget 7-->
										