													
													<!--begin:Row-->
													<div class="row" data-kt-menu-dismiss="true">
														<!--begin:Col-->
														<div class="col-lg-4 border-left-lg-1">
															<div class="menu-inline menu-column menu-active-bg">
																<div class="menu-item">
																	<a href="#" class="menu-link">
																		<span class="menu-bullet">
																			<span class="bullet bullet-dot"></span>
																		</span>
																		<span class="menu-title">Example link</span>
																	</a>
																</div>
																<div class="menu-item">
																	<a href="#" class="menu-link">
																		<span class="menu-bullet">
																			<span class="bullet bullet-dot"></span>
																		</span>
																		<span class="menu-title">Example link</span>
																	</a>
																</div>
																<div class="menu-item">
																	<a href="#" class="menu-link">
																		<span class="menu-bullet">
																			<span class="bullet bullet-dot"></span>
																		</span>
																		<span class="menu-title">Example link</span>
																	</a>
																</div>
																<div class="menu-item">
																	<a href="#" class="menu-link">
																		<span class="menu-bullet">
																			<span class="bullet bullet-dot"></span>
																		</span>
																		<span class="menu-title">Example link</span>
																	</a>
																</div>
																<div class="menu-item">
																	<a href="#" class="menu-link">
																		<span class="menu-bullet">
																			<span class="bullet bullet-dot"></span>
																		</span>
																		<span class="menu-title">Example link</span>
																	</a>
																</div>
															</div>
														</div>
														<!--end:Col-->
														<!--begin:Col-->
														<div class="col-lg-4 border-left-lg-1">
															<div class="menu-inline menu-column menu-active-bg">
																<div class="menu-item">
																	<a href="#" class="menu-link">
																		<span class="menu-bullet">
																			<span class="bullet bullet-dot"></span>
																		</span>
																		<span class="menu-title">Example link</span>
																	</a>
																</div>
																<div class="menu-item">
																	<a href="#" class="menu-link">
																		<span class="menu-bullet">
																			<span class="bullet bullet-dot"></span>
																		</span>
																		<span class="menu-title">Example link</span>
																	</a>
																</div>
																<div class="menu-item">
																	<a href="#" class="menu-link">
																		<span class="menu-bullet">
																			<span class="bullet bullet-dot"></span>
																		</span>
																		<span class="menu-title">Example link</span>
																	</a>
																</div>
																<div class="menu-item">
																	<a href="#" class="menu-link">
																		<span class="menu-bullet">
																			<span class="bullet bullet-dot"></span>
																		</span>
																		<span class="menu-title">Example link</span>
																	</a>
																</div>
																<div class="menu-item">
																	<a href="#" class="menu-link">
																		<span class="menu-bullet">
																			<span class="bullet bullet-dot"></span>
																		</span>
																		<span class="menu-title">Example link</span>
																	</a>
																</div>
															</div>
														</div>
														<!--end:Col-->
														<!--begin:Col-->
														<div class="col-lg-4 border-left-lg-1">
															<div class="menu-inline menu-column menu-active-bg">
																<div class="menu-item">
																	<a href="#" class="menu-link">
																		<span class="menu-bullet">
																			<span class="bullet bullet-dot"></span>
																		</span>
																		<span class="menu-title">Example link</span>
																	</a>
																</div>
																<div class="menu-item">
																	<a href="#" class="menu-link">
																		<span class="menu-bullet">
																			<span class="bullet bullet-dot"></span>
																		</span>
																		<span class="menu-title">Example link</span>
																	</a>
																</div>
																<div class="menu-item">
																	<a href="#" class="menu-link">
																		<span class="menu-bullet">
																			<span class="bullet bullet-dot"></span>
																		</span>
																		<span class="menu-title">Example link</span>
																	</a>
																</div>
																<div class="menu-item">
																	<a href="#" class="menu-link">
																		<span class="menu-bullet">
																			<span class="bullet bullet-dot"></span>
																		</span>
																		<span class="menu-title">Example link</span>
																	</a>
																</div>
																<div class="menu-item">
																	<a href="#" class="menu-link">
																		<span class="menu-bullet">
																			<span class="bullet bullet-dot"></span>
																		</span>
																		<span class="menu-title">Example link</span>
																	</a>
																</div>
															</div>
														</div>
														<!--end:Col-->
													</div>
													<!--end:Row-->
													