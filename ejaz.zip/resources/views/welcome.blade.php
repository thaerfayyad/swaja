@extends('layout.main')
@section('title','Welcome Page')
@section('css')
@endsection
@section('content')
<p>Welcome Page Content</p>
@endsection
@section('js')
@endsection
